const axios = require('axios');

const apiUrl = 'https://jsonplaceholder.typicode.com/comments';

async function fetchData() {
  try {
    const response = await axios.get(apiUrl);
    return response.data;
  } catch (error) {
    throw new Error('Error fetching data:', error.message);
  }
}

function filterCommentsByWord(data, word) {
  const filteredComments = data.filter(comment => comment.body.toLowerCase().includes(word.toLowerCase()));
  return filteredComments;
}

module.exports = {
  fetchData: fetchData,
  filterCommentsByWord: filterCommentsByWord
};
