const express = require('express');
const apiService = require('./apiService');

const app = express();
const PORT = 3000;

app.get('/', async (req, res) => {
  try {
    const data = await apiService.fetchData();
    const firstTenComments = data.slice(0, 10);
    res.send(`
      <h1>Comments</h1>
      <table border="1">
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Body</th>
        </tr>
        ${firstTenComments.map(comment => `
          <tr>
            <td>${comment.id}</td>
            <td>${comment.name}</td>
            <td>${comment.email}</td>
            <td>${comment.body}</td>
          </tr>
        `).join('')}
      </table>
      <br>
      <a href="/filter/aliquam"><button>Filter Comments containing 'aliquam'</button></a>
    `);
  } catch (error) {
    res.status(500).send('Error fetching data');
  }
});

app.get('/filter/:word', async (req, res) => {
  try {
    const word = req.params.word;
    const data = await apiService.fetchData();
    const filteredComments = apiService.filterCommentsByWord(data, word);
    res.send(`
      <h1>Filtered Comments (Containing '${word}')</h1>
      <table border="1">
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Body</th>
        </tr>
        ${filteredComments.map(comment => `
          <tr>
            <td>${comment.id}</td>
            <td>${comment.name}</td>
            <td>${comment.email}</td>
            <td>${comment.body}</td>
          </tr>
        `).join('')}
      </table>
    `);
  } catch (error) {
    res.status(500).send('Error filtering data');
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
